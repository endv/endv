﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Resources;

namespace Emotion2
{
    public partial class EmotionDropdown : UserControl// RichTextBox//FlowLayoutSettings// UserControl
    {
        private Popup _popup; 
        void  AddRangex() 
        { 

            this.emotionContainer1.Items.AddRange(new Emotion2.EmotionItem[] {

         new EmotionItem("0.gif", global::Emotion2.Properties.Resources._0),
new EmotionItem("1.gif", Properties.Resources._1),
new Emotion2.EmotionItem("2.gif", global::Emotion2.Properties.Resources._2),
new Emotion2.EmotionItem("3.gif", global::Emotion2.Properties.Resources._3),
new Emotion2.EmotionItem("4.gif", global::Emotion2.Properties.Resources._4),
new Emotion2.EmotionItem("5.gif", global::Emotion2.Properties.Resources._5),
new Emotion2.EmotionItem("6.gif", global::Emotion2.Properties.Resources._6),
new Emotion2.EmotionItem("7.gif", global::Emotion2.Properties.Resources._7),
new Emotion2.EmotionItem("8.gif", global::Emotion2.Properties.Resources._8),
new Emotion2.EmotionItem("9.gif", global::Emotion2.Properties.Resources._9),
new Emotion2.EmotionItem("10.gif", global::Emotion2.Properties.Resources._10),
new Emotion2.EmotionItem("11.gif", global::Emotion2.Properties.Resources._11),
new Emotion2.EmotionItem("12.gif", global::Emotion2.Properties.Resources._12),
new Emotion2.EmotionItem("13.gif", global::Emotion2.Properties.Resources._13),
new Emotion2.EmotionItem("14.gif", global::Emotion2.Properties.Resources._14),
new Emotion2.EmotionItem("15.gif", global::Emotion2.Properties.Resources._15),
new Emotion2.EmotionItem("16.gif", global::Emotion2.Properties.Resources._16),
new Emotion2.EmotionItem("17.gif", global::Emotion2.Properties.Resources._17),
new Emotion2.EmotionItem("18.gif", global::Emotion2.Properties.Resources._18),
new Emotion2.EmotionItem("19.gif", global::Emotion2.Properties.Resources._19),
new Emotion2.EmotionItem("20.gif", global::Emotion2.Properties.Resources._20),
new Emotion2.EmotionItem("21.gif", global::Emotion2.Properties.Resources._21),
new Emotion2.EmotionItem("22.gif", global::Emotion2.Properties.Resources._22),
new Emotion2.EmotionItem("23.gif", global::Emotion2.Properties.Resources._23),
new Emotion2.EmotionItem("24.gif", global::Emotion2.Properties.Resources._24),
new Emotion2.EmotionItem("27.gif", global::Emotion2.Properties.Resources._27),
new Emotion2.EmotionItem("25.gif", global::Emotion2.Properties.Resources._25),
new Emotion2.EmotionItem("26.gif", global::Emotion2.Properties.Resources._26),
new Emotion2.EmotionItem("28.gif", global::Emotion2.Properties.Resources._28),
new Emotion2.EmotionItem("29.gif", global::Emotion2.Properties.Resources._29),
new Emotion2.EmotionItem("30.gif", global::Emotion2.Properties.Resources._30),
new Emotion2.EmotionItem("31.gif", global::Emotion2.Properties.Resources._31),
new Emotion2.EmotionItem("32.gif", global::Emotion2.Properties.Resources._32),
new Emotion2.EmotionItem("33.gif", global::Emotion2.Properties.Resources._33),
new Emotion2.EmotionItem("34.gif", global::Emotion2.Properties.Resources._34),
new Emotion2.EmotionItem("35.gif", global::Emotion2.Properties.Resources._35),
new Emotion2.EmotionItem("36.gif", global::Emotion2.Properties.Resources._36),
new Emotion2.EmotionItem("37.gif", global::Emotion2.Properties.Resources._37),
new Emotion2.EmotionItem("38.gif", global::Emotion2.Properties.Resources._38),
new Emotion2.EmotionItem("39.gif", global::Emotion2.Properties.Resources._39),
new Emotion2.EmotionItem("40.gif", global::Emotion2.Properties.Resources._40),
new Emotion2.EmotionItem("41.gif", global::Emotion2.Properties.Resources._41),
new Emotion2.EmotionItem("42.gif", global::Emotion2.Properties.Resources._42),
new Emotion2.EmotionItem("43.gif", global::Emotion2.Properties.Resources._43),
new Emotion2.EmotionItem("44.gif", global::Emotion2.Properties.Resources._44),
new Emotion2.EmotionItem("45.gif", global::Emotion2.Properties.Resources._45),
new Emotion2.EmotionItem("46.gif", global::Emotion2.Properties.Resources._46),
new Emotion2.EmotionItem("47.gif", global::Emotion2.Properties.Resources._47),
new Emotion2.EmotionItem("48.gif", global::Emotion2.Properties.Resources._48),
new Emotion2.EmotionItem("49.gif", global::Emotion2.Properties.Resources._49),
new Emotion2.EmotionItem("50.gif", global::Emotion2.Properties.Resources._50),
new Emotion2.EmotionItem("51.gif", global::Emotion2.Properties.Resources._51),
new Emotion2.EmotionItem("52.gif", global::Emotion2.Properties.Resources._52),
new Emotion2.EmotionItem("53.gif", global::Emotion2.Properties.Resources._53),
new Emotion2.EmotionItem("54.gif", global::Emotion2.Properties.Resources._54),
new Emotion2.EmotionItem("55.gif", global::Emotion2.Properties.Resources._55),
new Emotion2.EmotionItem("56.gif", global::Emotion2.Properties.Resources._56),
new Emotion2.EmotionItem("57.gif", global::Emotion2.Properties.Resources._57),
new Emotion2.EmotionItem("58.gif", global::Emotion2.Properties.Resources._58),
new Emotion2.EmotionItem("59.gif", global::Emotion2.Properties.Resources._59),
new Emotion2.EmotionItem("60.gif", global::Emotion2.Properties.Resources._60),
new Emotion2.EmotionItem("61.gif", global::Emotion2.Properties.Resources._61),
new Emotion2.EmotionItem("62.gif", global::Emotion2.Properties.Resources._62),
new Emotion2.EmotionItem("63.gif", global::Emotion2.Properties.Resources._63),
new Emotion2.EmotionItem("64.gif", global::Emotion2.Properties.Resources._64),
new Emotion2.EmotionItem("65.gif", global::Emotion2.Properties.Resources._65),
new Emotion2.EmotionItem("66.gif", global::Emotion2.Properties.Resources._66),
new Emotion2.EmotionItem("67.gif", global::Emotion2.Properties.Resources._67),
new Emotion2.EmotionItem("68.gif", global::Emotion2.Properties.Resources._68),
new Emotion2.EmotionItem("69.gif", global::Emotion2.Properties.Resources._69),
new Emotion2.EmotionItem("70.gif", global::Emotion2.Properties.Resources._70),
new Emotion2.EmotionItem("71.gif", global::Emotion2.Properties.Resources._71),
new Emotion2.EmotionItem("72.gif", global::Emotion2.Properties.Resources._72),
new Emotion2.EmotionItem("73.gif", global::Emotion2.Properties.Resources._73),
new Emotion2.EmotionItem("74.gif", global::Emotion2.Properties.Resources._74),
new Emotion2.EmotionItem("75.gif", global::Emotion2.Properties.Resources._75),
new Emotion2.EmotionItem("76.gif", global::Emotion2.Properties.Resources._76),
new Emotion2.EmotionItem("77.gif", global::Emotion2.Properties.Resources._77),
new Emotion2.EmotionItem("78.gif", global::Emotion2.Properties.Resources._78),
new Emotion2.EmotionItem("79.gif", global::Emotion2.Properties.Resources._79),
new Emotion2.EmotionItem("80.gif", global::Emotion2.Properties.Resources._80),
new Emotion2.EmotionItem("81.gif", global::Emotion2.Properties.Resources._81),
new Emotion2.EmotionItem("82.gif", global::Emotion2.Properties.Resources._82),
new Emotion2.EmotionItem("83.gif", global::Emotion2.Properties.Resources._83),
new Emotion2.EmotionItem("84.gif", global::Emotion2.Properties.Resources._84),
new Emotion2.EmotionItem("85.gif", global::Emotion2.Properties.Resources._85),
new Emotion2.EmotionItem("86.gif", global::Emotion2.Properties.Resources._86),
new Emotion2.EmotionItem("87.gif", global::Emotion2.Properties.Resources._87),
new Emotion2.EmotionItem("88.gif", global::Emotion2.Properties.Resources._88),
new Emotion2.EmotionItem("89.gif", global::Emotion2.Properties.Resources._89),
new Emotion2.EmotionItem("90.gif", global::Emotion2.Properties.Resources._90),
new Emotion2.EmotionItem("91.gif", global::Emotion2.Properties.Resources._91),
new Emotion2.EmotionItem("92.gif", global::Emotion2.Properties.Resources._92),
new Emotion2.EmotionItem("93.gif", global::Emotion2.Properties.Resources._93),
new Emotion2.EmotionItem("94.gif", global::Emotion2.Properties.Resources._94),
new Emotion2.EmotionItem("95.gif", global::Emotion2.Properties.Resources._95),
new Emotion2.EmotionItem("96.gif", global::Emotion2.Properties.Resources._96),
new Emotion2.EmotionItem("97.gif", global::Emotion2.Properties.Resources._97),
new Emotion2.EmotionItem("98.gif", global::Emotion2.Properties.Resources._98),
new Emotion2.EmotionItem("99.gif", global::Emotion2.Properties.Resources._99),
new Emotion2.EmotionItem("100.gif", global::Emotion2.Properties.Resources._100),
new Emotion2.EmotionItem("101.gif", global::Emotion2.Properties.Resources._101),
new Emotion2.EmotionItem("102.gif", global::Emotion2.Properties.Resources._102),
new Emotion2.EmotionItem("103.gif", global::Emotion2.Properties.Resources._103),
new Emotion2.EmotionItem("104.gif", global::Emotion2.Properties.Resources._104),
new Emotion2.EmotionItem("105.gif", global::Emotion2.Properties.Resources._105),
new Emotion2.EmotionItem("106.gif", global::Emotion2.Properties.Resources._106),
new Emotion2.EmotionItem("107.gif", global::Emotion2.Properties.Resources._107),
new Emotion2.EmotionItem("108.gif", global::Emotion2.Properties.Resources._108),
new Emotion2.EmotionItem("109.gif", global::Emotion2.Properties.Resources._109),
new Emotion2.EmotionItem("110.gif", global::Emotion2.Properties.Resources._110),
new Emotion2.EmotionItem("111.gif", global::Emotion2.Properties.Resources._111),
new Emotion2.EmotionItem("112.gif", global::Emotion2.Properties.Resources._112),
new Emotion2.EmotionItem("113.gif", global::Emotion2.Properties.Resources._113),
new Emotion2.EmotionItem("114.gif", global::Emotion2.Properties.Resources._114),
new Emotion2.EmotionItem("115.gif", global::Emotion2.Properties.Resources._115),
new Emotion2.EmotionItem("116.gif", global::Emotion2.Properties.Resources._116),
new Emotion2.EmotionItem("117.gif", global::Emotion2.Properties.Resources._117),
new Emotion2.EmotionItem("118.gif", global::Emotion2.Properties.Resources._118),
new Emotion2.EmotionItem("119.gif", global::Emotion2.Properties.Resources._119),
new Emotion2.EmotionItem("120.gif", global::Emotion2.Properties.Resources._120),
new Emotion2.EmotionItem("121.gif", global::Emotion2.Properties.Resources._121),
new Emotion2.EmotionItem("122.gif", global::Emotion2.Properties.Resources._122),
new Emotion2.EmotionItem("123.gif", global::Emotion2.Properties.Resources._123),
new Emotion2.EmotionItem("124.gif", global::Emotion2.Properties.Resources._124),
new Emotion2.EmotionItem("125.gif", global::Emotion2.Properties.Resources._125),
new Emotion2.EmotionItem("126.gif", global::Emotion2.Properties.Resources._126),
new Emotion2.EmotionItem("127.gif", global::Emotion2.Properties.Resources._127),
new Emotion2.EmotionItem("128.gif", global::Emotion2.Properties.Resources._128),
new Emotion2.EmotionItem("129.gif", global::Emotion2.Properties.Resources._129),
new Emotion2.EmotionItem("130.gif", global::Emotion2.Properties.Resources._130),
new Emotion2.EmotionItem("131.gif", global::Emotion2.Properties.Resources._131),
new Emotion2.EmotionItem("132.gif", global::Emotion2.Properties.Resources._132),
new Emotion2.EmotionItem("133.gif", global::Emotion2.Properties.Resources._133),
new Emotion2.EmotionItem("134.gif", global::Emotion2.Properties.Resources._134)
            }); 


        }
        public EmotionDropdown()
        {
            InitializeComponent();
      
            AddRangex();
          
            _popup = new Popup(this);

            EmotionContainer.ItemClick +=
                new EmotionItemMouseEventHandler(EmotionContainerItemClick); 
        }
        /// <summary>
        ///  单击
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void EmotionContainerItemClick( object sender, EmotionItemMouseClickEventArgs e)
        {
            _popup.Close();
        }
        /// <summary>
        /// 表情容器
        /// </summary>
        public EmotionContainer EmotionContainer
        {
            get { return emotionContainer1; }
        }

        public void Show(Control owner)
        {
            _popup.Show(owner, true);
        }

      
    }
}
